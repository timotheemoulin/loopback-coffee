module.exports = function (Drinker) {

};
